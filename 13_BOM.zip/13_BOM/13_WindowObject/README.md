# Browser Object Modeling (BOM)
1. window object properties are available in the global scope.
2. all global variables and functions or with var become properties and methods of the window object.
3. let or const vaiables and functions are not attached to window object.