function backTo() {
  history.back();
}

function nextTo() {
  history.forward();
}



console.log(`Document location: ${document.location}`);
console.log(`Window location: ${window.location}`);
console.log(`location.hash: ${location.hash}`);
console.log(`location.host: ${location.host}`);
console.log(`location.hostname: ${location.hostname}`);
console.log(`location.href: ${location.href}`);
console.log(`location.pathname: ${location.pathname}`);
console.log(`location.port: ${location.port}`);
console.log(`location.protocal: ${location.protocol}`);
console.log(`location.search: ${location.search}`);

