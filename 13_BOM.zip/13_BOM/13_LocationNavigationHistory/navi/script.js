function backTo() {
  history.back();
}

function nextTo() {
  history.forward();
}


console.log(`location: ${document.location}`);
console.log(`window.navigator : ${window.navigator}`);
console.log(`navigator.cookieEnabled : ${navigator.cookieEnabled}`);
console.log(`navigator.vendor : ${navigator.vendor}`);
console.log(`navigator.language : ${navigator.language}`);



