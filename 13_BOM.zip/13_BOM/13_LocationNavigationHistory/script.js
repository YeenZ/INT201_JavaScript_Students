function backTo() {
  history.back();
}

function nextTo() {
  history.forward();
}
console.log(`history.length: ${history.length}`);


