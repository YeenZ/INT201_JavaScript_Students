function scrollToContactUs() {
  imageHeight = document.getElementById("it1").height;
  window.scrollTo(window.innerWidth, imageHeight);
}

function sizing(){
  window.resizeTo(200, 200);
}

function close_window() {
  alert("Good bye, See you next time!");
  window.close();
}

