# System Dialogs
- Three system dialogs: alert(), confirm(), and prompt() to display to the user through the  methods.
1. A alert() method simply accepts a string to display to the user with only OK button.
2. A confirm() method similars to an alert dialog in that it displays a message to the user.  It returns a Boolean value: true if OK was clicked, or false if Cancel was clicked or the dialog is otherwise closed without clicking OK, the function returns null
3. A prompt() method prompts the user for input with two arguments: the text to display to the user, and the default value for the text box (which can be an empty string). 

 
