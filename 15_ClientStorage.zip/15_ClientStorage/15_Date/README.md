# DateTime
two Local Time and Coordinated Universal Time (UTC).
  - Local time refers to the timezone your computer is in. By default, every date method in JavaScript gives your date in local time. 
  - Coordinated Universal Time (UTC) is the global standard time defined by the World Time Standard.  


