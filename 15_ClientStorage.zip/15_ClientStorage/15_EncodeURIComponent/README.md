# encodingURIComponent()
- The encodeURIComponent() function encodes a URI component by representing the UTF-8 encoding of the character.
- This function encodes special characters: , / ? : @ & = + $ #  
- The characters A-Z a-z 0-9 - _ . ! ~ * ' ( ) are not escaped.
- Use the decodeURIComponent() function to decode an encoded URI component.


