# Cookie Practice
1. create event onclick on each provided color box and when a user clicks on that color box, change a background color to that color.
2. Then remember user's favorite color by storing selected background color to cookie with 7 days expired.
3. When window loading next time, set favorite color to his/her visiting page background.

