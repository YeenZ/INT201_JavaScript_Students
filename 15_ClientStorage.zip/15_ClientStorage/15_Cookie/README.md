# Cookies
- HTTP cookies or web cookies or browser cookies, commonly called "cookies", is a small piece of data that a server sends to the user’s web browser.  
- Cookies are a general mechanism which server-side connections can use to both store and retrieve information on the client side. It remembers stateful information for the stateless HTTP protocol.

